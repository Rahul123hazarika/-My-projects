
import cv2
import numpy as np
from pathlib import Path
import zipfile
import os

# ---------------- Step 1: Extract ZIP file ----------------
zip_path = "images (1).zip"
extract_dir = Path("input_images")
extract_dir.mkdir(exist_ok=True)

if os.path.exists(zip_path):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
    print(f" Extracted images to: {extract_dir}")
else:
    print(f"'{zip_path}' not found. Please add it to this folder.")
    exit()

def unsharp_mask(img, kernel_size=(0,0), sigma=1.0, amount=1.0, threshold=0):
    blurred = cv2.GaussianBlur(img, (0,0), sigma)
    sharpened = float(amount + 1) * img - float(amount) * blurred
    sharpened = np.clip(sharpened, 0, 255).astype(np.uint8)
    return sharpened

def enhance_image(input_path, output_path):
    img = cv2.imread(str(input_path))
    if img is None:
        print(f"⚠️ Skipped (not readable): {input_path.name}")
        return
    
    img_ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    y, cr, cb = cv2.split(img_ycrcb)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    y = clahe.apply(y)
    img_ycrcb = cv2.merge((y, cr, cb))
    img = cv2.cvtColor(img_ycrcb, cv2.COLOR_YCrCb2BGR)

    # 2. Denoise while preserving edges
    img = cv2.bilateralFilter(img, 9, 75, 75)

    # 3. Detail enhancement
    img = cv2.detailEnhance(img, sigma_s=10, sigma_r=0.15)

    # 4. Unsharp mask (sharpen)
    img = unsharp_mask(img, sigma=1.0, amount=1.0)

    cv2.imwrite(str(output_path), img)

# ---------------- Step 3: Process all images ----------------
output_dir = Path("Enhanced_Images")
output_dir.mkdir(exist_ok=True)

for img_path in extract_dir.glob("*.*"):
    if img_path.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]:
        out_path = output_dir / img_path.name
        enhance_image(img_path, out_path)
        print(f"✅ Enhanced: {img_path.name}")

print("\nAll images processed successfully!")
print(f"Check the folder: '{output_dir}'")
